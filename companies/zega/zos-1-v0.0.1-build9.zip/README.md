# ZOS — Zega OS v0.0.1

Phase 9 builds on the Phase 7/8 foundation with two new userland apps (Notepad and System Monitor), a Vulkan GPU abstraction layer, and significant performance optimizations using 64-bit bulk memory operations.

Expected behavior inside QEMU:

```text
ZOS v0.0.1 - Zega OS  Phase 9
Boot path : GRUB / Multiboot2
CPU mode  : x86_64 long mode
Video     : framebuffer ready
Renderer  : double buffering enabled (64-bit optimized)
GPU       : Vulkan-inspired abstraction active
Desktop   : window manager active
Windows   : z-ordering enabled
Mouse     : PS/2 IRQ12 enabled
Apps      : Calculator, Text Viewer, Notepad, System Monitor
Controls  : drag windows by their title bars.
```

If GRUB honors the framebuffer request, the QEMU window should show a desktop background with multiple overlapping windows and a visible mouse cursor. Clicking a window should bring it to the front, and dragging its title bar should move it across the desktop. The APPS launcher provides buttons to toggle each application.

## Phase 9 Features

### Notepad App

- Editable text area with keyboard input routed from the window manager.
- SAVE button writes content to the OFS VFS with auto-generated filenames (NOTE001.TXT, NOTE002.TXT, ...).
- CLEAR button empties the text area. NEW button increments the file counter.
- Saved files appear immediately in the OFS FILES window and are readable in the Text Viewer.

### System Monitor

- Real-time display of uptime (HH:MM:SS), tick count, PIT frequency, heap size, free pages, window/widget count, and GPU stats.
- Auto-refreshes every frame when the window is visible.

### GPU Abstraction Layer

- Uses Vulkan GPU abstraction layer.
- Records draw commands into a flat buffer and replays against the software renderer at present time.
- Tracks frame count, draw calls per frame, and dropped commands.
- Provides a migration path toward real GPU drivers in future versions.

### Performance Optimizations

- `memory_set` and `memory_copy` use 64-bit word-sized operations with 4-wide unrolled loops.
- `renderer_clear` and `renderer_fill_rect` use 64-bit pair writes for ~2x throughput.
- `renderer_draw_rect` uses direct pixel loops instead of generic Bresenham for axis-aligned edges.
- `renderer_draw_line` uses fast paths for horizontal and vertical lines.
- `framebuffer_present` XRGB32 path uses unrolled 64-bit bulk copies.

### Previous Phase Concepts

#### Mouse Input
- The PS/2 mouse sends movement and button state through IRQ12 as 3-byte packets.
- The driver enables the auxiliary device through the 8042 controller, turns on streaming, and updates a shared cursor state.

#### Window Records
- Each window stores position, size, and a few colors for title bar and content styling.
- The manager keeps a separate order array so stacking can change without moving window storage.

#### Z-Ordering
- The topmost visible window is simply the last entry in the draw-order list.
- When the cursor clicks a window, the manager moves that window's slot to the end of the order array.

#### Dragging
- Dragging starts only when the left mouse button is pressed inside a title bar.
- The manager records the cursor-to-window offset and repositions the window on later mouse updates until the button is released.

#### Double-Buffered Desktop
- Desktop background, windows, and cursor are all drawn into the software backbuffer first.
- `renderer_present` copies the completed frame to the hardware framebuffer in one pass, which keeps mouse-driven redraws visually stable.
