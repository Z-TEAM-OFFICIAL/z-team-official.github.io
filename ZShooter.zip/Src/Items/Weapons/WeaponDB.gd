class_name WeaponDB

static func all_defs() -> Dictionary:
	var defs = {}
	var types = ["lightweight-machinegun", "pistol", "rifle", "shotgun", "heavy-rifle", "sniper", "rpg"]
	var base_damages = [8, 15, 25, 35, 45, 60, 100]
	var base_fire_rates = [0.08, 0.15, 0.25, 0.5, 0.35, 0.8, 1.2]

	for i in range(types.size()):
		var t = types[i]
		for tier_name in ["steel", "titanium"]:
			var mult = 1.0 if tier_name == "steel" else 1.5
			var w = WeaponDef.new()
			w.id = tier_name + "-" + t
			w.tier = tier_name
			w.weapon_type = t
			w.display_name = tier_name.capitalize() + " " + _display_of(t)
			w.damage = int(base_damages[i] * mult)
			w.fire_rate = base_fire_rates[i]
			w.spread = 0.0
			w.model_tint = Color(0.7, 0.7, 0.8, 1) if tier_name == "steel" else Color(0.4, 0.5, 0.8, 1)
			defs[w.id] = w
	return defs

static func _display_of(t: String) -> String:
	match t:
		"lightweight-machinegun": return "Lightweight Machinegun"
		"pistol": return "Pistol"
		"rifle": return "Rifle"
		"shotgun": return "Shotgun"
		"heavy-rifle": return "Heavy Rifle"
		"sniper": return "Sniper"
		"rpg": return "RPG"
	return t
