extends Resource
class_name WeaponDef

@export var id: String
@export var tier: String  # "steel" or "titanium"
@export var weapon_type: String  # weapon type name
@export var display_name: String
@export var damage: int = 25
@export var fire_rate: float = 0.25
@export var spread: float = 0.0
@export var model_tint: Color = Color(0.7, 0.7, 0.7, 1)
