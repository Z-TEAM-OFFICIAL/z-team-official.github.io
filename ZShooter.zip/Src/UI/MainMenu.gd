extends Control

var save_manager: Node = null

@onready var settings_menu = $SettingsMenu
@onready var mod_menu = $ModMenu
@onready var save_browser = $SaveBrowser
@onready var lan_dialog = $LANDialog
@onready var lan_connect_btn = $Panel/VBoxContainer/LANConnect

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	save_manager = $SaveManager
	settings_menu.closed.connect(_on_settings_closed)
	settings_menu.hide()
	mod_menu.closed.connect(_on_mod_menu_closed)
	mod_menu.hide()
	save_browser.closed.connect(_on_save_browser_closed)
	save_browser.hide()
	lan_dialog.hide()
	save_browser.set_save_manager(save_manager)
	lan_connect_btn.text = "LAN Connect (" + $NetworkManager.get_local_ip() + ":" + str($NetworkManager.get_port()) + ")"

func _input(event):
	if event.is_action_pressed("ui_cancel"):
		if settings_menu.visible:
			settings_menu.hide()
		elif mod_menu.visible:
			mod_menu.close()
		elif save_browser.visible:
			save_browser.close()
		elif lan_dialog.visible:
			lan_dialog.hide()
		else:
			get_tree().quit()

func _on_play_pressed():
	if not $NetworkManager.is_network_connected():
		print("Cannot start game: Not connected to a network.")
		return
	Store.load_slot = -1
	get_tree().change_scene_to_file("res://Src/Core/Main.tscn")

func _on_load_pressed():
	save_browser.refresh()
	save_browser.show()

func _on_mods_pressed():
	mod_menu.scan_mods()
	mod_menu.show()

func _on_settings_pressed():
	settings_menu.show()

func _on_lan_connect_pressed():
	lan_dialog.show()
	$LANDialog/VBoxContainer/IPInput.grab_focus()

func _on_join_pressed():
	var ip_port = $LANDialog/VBoxContainer/IPInput.text.strip_edges()
	if ip_port == "":
		return
	var parts = ip_port.split(":")
	if parts.size() == 2:
		var ip = parts[0]
		var port = int(parts[1])
		if $NetworkManager.join_game(ip, port):
			get_tree().change_scene_to_file("res://Src/Core/Main.tscn")
	lan_dialog.hide()

func _on_cancel_pressed():
	lan_dialog.hide()

func _on_settings_closed():
	settings_menu.hide()

func _on_mod_menu_closed():
	mod_menu.hide()

func _on_save_browser_closed():
	save_browser.hide()

func _on_quit_pressed():
	get_tree().quit()
