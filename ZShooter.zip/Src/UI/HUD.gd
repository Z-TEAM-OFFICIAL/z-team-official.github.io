extends CanvasLayer

@onready var health_label: Label = $HealthLabel
@onready var score_label: Label = $ScoreLabel
@onready var fps_label: Label = $FPSLabel
@onready var game_over_label: Label = $GameOverLabel
@onready var restart_button: Button = $RestartButton
@onready var damage_overlay: ColorRect = $DamageOverlay
@onready var render_dist_label: Label = $RenderDistLabel
@onready var pause_label: Label = $PauseLabel
@onready var weapon_label: Label = $WeaponLabel
@onready var ammo_label: Label = $AmmoLabel
@onready var ip_label: Label = $IPLabel

var time: float = 0.0

func _ready():
	game_over_label.hide()
	restart_button.hide()
	pause_label.hide()
	restart_button.pressed.connect(_on_restart)
	damage_overlay.material.set("shader_parameter/intensity", 0.0)
	weapon_label.text = ""
	ammo_label.text = ""

func _process(delta):
	time += delta
	if time >= 0.5:
		fps_label.text = "FPS: " + str(Engine.get_frames_per_second())
		time = 0.0

func update_health(value: int):
	health_label.text = "HP: " + str(value)
	if value < 30:
		health_label.modulate = Color.RED
	else:
		health_label.modulate = Color.WHITE
	flash_damage()

func update_score(value: int):
	score_label.text = "Score: " + str(value)

func update_render_distance(dist: float):
	render_dist_label.text = "View: %.0fm" % dist

func update_weapon_display(_index: int, weapon):
	if weapon:
		weapon_label.text = weapon.display_name
		var player = get_tree().get_first_node_in_group("player")
		if player and player.weapon_manager:
			var ammo = player.weapon_manager.get_current_ammo()
			ammo_label.text = "Ammo: " + str(ammo)
	else:
		weapon_label.text = ""
		ammo_label.text = ""

func show_pause():
	pause_label.show()

func hide_pause():
	pause_label.hide()

func show_ip(text: String):
	ip_label.text = text

func flash_damage():
	var mat = damage_overlay.material
	var tween = create_tween()
	tween.tween_property(mat, "shader_parameter/intensity", 0.6, 0.05)
	tween.tween_property(mat, "shader_parameter/intensity", 0.0, 0.3)

func show_game_over():
	game_over_label.show()
	restart_button.show()

func _on_restart():
	get_tree().reload_current_scene()
