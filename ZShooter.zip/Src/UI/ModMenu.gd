extends Control

signal closed

func close():
	hide()
	closed.emit()
