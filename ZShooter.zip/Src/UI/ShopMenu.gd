extends Control

signal closed

var player: Node3D = null

const COST_DAMAGE = 50
const COST_FIRERATE = 50
const COST_HEALTH = 50

var bought_damage = false
var bought_firerate = false
var bought_health = false

func _ready():
	update_display()

func set_player(p):
	player = p
	update_display()

func _on_damage_pressed():
	if not player or bought_damage:
		return
	if player.score >= COST_DAMAGE:
		player.score -= COST_DAMAGE
		bought_damage = true
		player.damage_multiplier = 2.0
		update_display()

func _on_firerate_pressed():
	if not player or bought_firerate:
		return
	if player.score >= COST_FIRERATE:
		player.score -= COST_FIRERATE
		bought_firerate = true
		player.fire_rate_multiplier = 0.5
		update_display()

func _on_health_pressed():
	if not player or bought_health:
		return
	if player.score >= COST_HEALTH:
		player.score -= COST_HEALTH
		bought_health = true
		player.max_health += 50
		player.health = player.max_health
		update_display()

func update_display():
	if not player:
		return
	$Panel/VBoxContainer/ScoreLabel.text = "Score: %d" % player.score
	_update_button($Panel/VBoxContainer/Damage, bought_damage, COST_DAMAGE, "2x Damage")
	_update_button($Panel/VBoxContainer/FireRate, bought_firerate, COST_FIRERATE, "2x Fire Rate")
	_update_button($Panel/VBoxContainer/Health, bought_health, COST_HEALTH, "+50 HP")

func _update_button(container: HBoxContainer, bought: bool, cost: int, label: String):
	if bought:
		container.get_node("Label").text = label + " [SOLD]"
		container.get_node("Cost").text = ""
		container.get_node("Buy").disabled = true
		container.get_node("Buy").text = "Owned"
	else:
		container.get_node("Label").text = label
		container.get_node("Cost").text = "%d pts" % cost
		container.get_node("Buy").disabled = false
		container.get_node("Buy").text = "Buy"

func _on_back_pressed():
	closed.emit()
	hide()
