extends Control

signal slot_selected(slot: int)
signal closed

var save_manager: Node = null
var slots: Array = []

@onready var container: VBoxContainer = $Panel/VBoxContainer/ScrollContainer/SlotList
@onready var scroll: ScrollContainer = $Panel/VBoxContainer/ScrollContainer
@onready var info_label: Label = $Panel/VBoxContainer/InfoLabel

func _ready():
	refresh()

func set_save_manager(mgr):
	save_manager = mgr
	refresh()

func refresh():
	for c in container.get_children():
		c.queue_free()
	slots.clear()
	
	if save_manager == null or not save_manager.has_method("get_save_slots"):
		return

	slots = save_manager.get_save_slots()
	for s in slots:
		var hbox = HBoxContainer.new()
		var label = Label.new()
		if s.exists:
			label.text = "Slot " + str(s.index) + " | Score: " + str(s.score) + " | HP: " + str(s.health) + " | " + s.timestamp
		else:
			label.text = "Slot " + str(s.index) + " - EMPTY"
		label.size_flags_horizontal = 3
		var btn = Button.new()
		btn.text = "Load" if s.exists else "Save"
		btn.disabled = not s.exists
		btn.pressed.connect(_on_slot_clicked.bind(s.index, s.exists))
		hbox.add_child(label)
		hbox.add_child(btn)
		container.add_child(hbox)

	if slots.size() == 0:
		info_label.text = "No save slots"

func _on_slot_clicked(slot: int, exists: bool):
	if exists:
		slot_selected.emit(slot)
		hide()

func close():
	hide()
	closed.emit()
