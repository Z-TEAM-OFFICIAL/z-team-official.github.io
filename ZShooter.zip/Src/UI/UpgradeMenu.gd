extends Control

signal closed

var player: Node3D = null

const UPGRADE_COST_BASE = 10

var health_level = 0
var damage_level = 0
var firerate_level = 0

func _ready():
	update_display()

func set_player(p):
	player = p
	update_display()

func _on_damage_pressed():
	if player and player.score >= cost_for_level(damage_level):
		player.score -= cost_for_level(damage_level)
		damage_level += 1
		player.damage_multiplier = 1.0 + damage_level * 0.25
		update_display()

func _on_firerate_pressed():
	if player and player.score >= cost_for_level(firerate_level):
		player.score -= cost_for_level(firerate_level)
		firerate_level += 1
		player.fire_rate_multiplier = 1.0 / (1.0 + firerate_level * 0.2)
		update_display()

func _on_health_pressed():
	if player and player.score >= cost_for_level(health_level):
		player.score -= cost_for_level(health_level)
		health_level += 1
		player.max_health = player.max_health + 20
		player.health = player.max_health
		update_display()

func cost_for_level(level: int) -> int:
	return UPGRADE_COST_BASE * (level + 1)

func update_display():
	if not player:
		return
	$Panel/VBoxContainer/ScoreLabel.text = "Score: %d" % player.score
	$Panel/VBoxContainer/Damage/Cost.text = "Cost: %d" % cost_for_level(damage_level)
	$Panel/VBoxContainer/FireRate/Cost.text = "Cost: %d" % cost_for_level(firerate_level)
	$Panel/VBoxContainer/Health/Cost.text = "Cost: %d" % cost_for_level(health_level)
	$Panel/VBoxContainer/Damage/Level.text = "Level: %d (+%d%%)" % [damage_level, damage_level * 25]
	$Panel/VBoxContainer/FireRate/Level.text = "Level: %d" % firerate_level
	$Panel/VBoxContainer/Health/Level.text = "Level: %d (+%d HP)" % [health_level, health_level * 20]

func _on_back_pressed():
	closed.emit()
	hide()
