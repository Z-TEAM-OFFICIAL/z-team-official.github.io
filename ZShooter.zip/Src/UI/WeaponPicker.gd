extends Control

signal closed

var weapon_defs: Dictionary = {}

@onready var title: Label = $Panel/VBoxContainer/TitleLabel
@onready var weapon_list: VBoxContainer = $Panel/VBoxContainer/WeaponList
@onready var scroll: ScrollContainer = $Panel/VBoxContainer/ScrollContainer

func _ready():
	weapon_defs = WeaponDB.all_defs()
	scroll.hide()

func show_for_cheat():
	scroll.show()
	title.text = "CHEATS"
	_populate_list(true)

func show_for_loadout():
	scroll.show()
	title.text = "SELECT STARTING WEAPON"
	_populate_list(false)

func _populate_list(for_cheat: bool):
	for c in weapon_list.get_children():
		c.queue_free()
	for id in weapon_defs:
		var w = weapon_defs[id]
		var btn = Button.new()
		btn.text = w.display_name + "  (DMG: " + str(w.damage) + " ROF: " + str(w.fire_rate) + ")"
		btn.connect("pressed", Callable(self, "_on_weapon_picked").bind(id, for_cheat))
		weapon_list.add_child(btn)

func _on_weapon_picked(id: String, for_cheat: bool):
	closed.emit()
	return id

func close():
	hide()
