extends Control

signal closed

const SETTINGS_PATH = "user://settings.cfg"

var config: ConfigFile

func _ready():
	config = ConfigFile.new()
	config.load(SETTINGS_PATH)
	$Panel/VBoxContainer/MouseSensitivity.value = config.get_value("settings", "mouse_sensitivity", 0.3)
	$Panel/VBoxContainer/MasterVolume.value = config.get_value("settings", "master_volume", 0.8)
	$Panel/VBoxContainer/MouseLock.button_pressed = config.get_value("settings", "mouse_lock", true)
	$Panel/VBoxContainer/VSync.button_pressed = config.get_value("settings", "v_sync", true)
	_on_mouse_sensitivity_value_changed($Panel/VBoxContainer/MouseSensitivity.value)
	_on_master_volume_value_changed($Panel/VBoxContainer/MasterVolume.value)

func _on_mouse_sensitivity_value_changed(value: float):
	$Panel/VBoxContainer/MouseSensiLabel.text = "Mouse Sensitivity: %.2f" % value
	config.set_value("settings", "mouse_sensitivity", value)
	save()

func _on_master_volume_value_changed(value: float):
	$Panel/VBoxContainer/VolumeLabel.text = "Master Volume: %d%%" % int(value * 100)
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Master"), linear_to_db(value))
	config.set_value("settings", "master_volume", value)
	save()

func _on_mouse_lock_toggled(toggled_on: bool):
	config.set_value("settings", "mouse_lock", toggled_on)
	save()

func _on_v_sync_toggled(toggled_on: bool):
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if toggled_on else DisplayServer.VSYNC_DISABLED)
	config.set_value("settings", "v_sync", toggled_on)
	save()

func save():
	config.save(SETTINGS_PATH)

func apply_from_config():
	config.load(SETTINGS_PATH)
	var vsync = config.get_value("settings", "v_sync", true)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if vsync else DisplayServer.VSYNC_DISABLED)

func _on_back_pressed():
	closed.emit()
	hide()

func get_sensitivity() -> float:
	return config.get_value("settings", "mouse_sensitivity", 0.3)

func get_mouse_lock() -> bool:
	return config.get_value("settings", "mouse_lock", true)
