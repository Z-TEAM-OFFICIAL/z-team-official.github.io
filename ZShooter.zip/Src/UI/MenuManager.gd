extends Control

var player_node = null
var hud = null
var save_manager = null
var cheat_console = null
var save_dialog = null

func _ready():
	process_mode = PROCESS_MODE_ALWAYS
	save_dialog = $SaveDialog
	save_dialog.hide()

func set_player(p):
	player_node = p

func set_hud(h):
	hud = h

func set_save_manager(mgr):
	save_manager = mgr

func set_cheat_console(cc):
	cheat_console = cc
	if cheat_console and player_node:
		cheat_console.set_player(player_node)

func _input(event):
	if event.is_action_pressed("pause"):
		if get_tree().paused:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			get_tree().paused = false
			if hud:
				hud.hide_pause()
		else:
			get_tree().paused = true
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			if hud:
				hud.show_pause()
	if event.is_action_pressed("save_game") and player_node:
		_show_save_dialog()
	if event.is_action_pressed("ui_cancel"):
		if get_tree().paused:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			get_tree().paused = false
			if hud:
				hud.hide_pause()

func _show_save_dialog():
	if save_manager == null:
		return
	var slots = save_manager.get_save_slots()
	var list = save_dialog.get_node("VBoxContainer/SlotList")
	for c in list.get_children():
		c.queue_free()
	for s in slots:
		var btn = Button.new()
		if s.exists:
			btn.text = "Slot " + str(s.index) + " (" + str(s.score) + ")"
		else:
			btn.text = "Slot " + str(s.index) + " - EMPTY"
		btn.pressed.connect(_on_save_slot.bind(s.index))
		list.add_child(btn)
	save_dialog.popup_centered(Vector2i(400, 300))

func _on_save_slot(slot):
	save_dialog.hide()
	if save_manager and player_node:
		save_manager.save_game(slot, player_node, player_node.weapon_manager)
		if hud:
			var label = Label.new()
			label.text = "SAVED"
			label.position = Vector2(get_viewport().size.x / 2 - 50, 150)
			label.add_theme_font_size_override("font_size", 32)
			add_child(label)
			var tw = create_tween()
			tw.tween_property(label, "modulate:a", 0.0, 1.5)
			tw.tween_callback(Callable(label, "queue_free"))

func _on_quit_pressed():
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://Src/UI/MainMenu.tscn")
