extends Control

var player = null
var weapon_defs = {}
var was_paused = false

@onready var input_field = $Panel/Input
@onready var output = $Panel/OutputContainer/Output
@onready var scroll = $Panel/OutputContainer

func _ready():
	weapon_defs = WeaponDB.all_defs()
	hide()

func set_player(p):
	player = p

func _input(event):
	if event.is_action_pressed("cheat_console"):
		if visible:
			hide()
			input_field.text = ""
			if not was_paused:
				get_tree().paused = false
				Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		else:
			was_paused = get_tree().paused
			get_tree().paused = true
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			show()
			input_field.grab_focus()
		get_viewport().set_input_as_handled()

func _on_command(cmd):
	cmd = cmd.strip_edges()
	if cmd == "":
		return
	_execute(cmd)
	input_field.clear()

func _execute(cmd):
	var parts = cmd.split(" ", false)
	if parts.size() == 0:
		return
	var command = parts[0].to_lower()

	match command:
		"give":
			if parts.size() < 2:
				return
			if parts[1] == "all":
				for id in weapon_defs:
					_give_weapon(id)
			else:
				_give_weapon(parts[1])
		"god":
			if player:
				player.god_mode = not player.god_mode
		"kill":
			for e in get_tree().get_nodes_in_group("enemies"):
				e.queue_free()
		"health":
			if parts.size() >= 2 and player:
				var amt = int(parts[1])
				player.health = clampi(player.health + amt, 0, player.max_health)
				player.health_changed.emit(player.health)
		"score":
			if parts.size() >= 2 and player:
				player.add_score(int(parts[1]))
		"help":
			pass

func _give_weapon(id):
	if not player:
		return
	if not id in weapon_defs:
		return
	var wm = player.weapon_manager
	if wm:
		wm.add_weapon(weapon_defs[id])
