extends Node

const SAVE_DIR = "user://saves/"
const MAX_SLOTS = 5

func _ready():
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(SAVE_DIR))

func get_save_slots() -> Array:
	var slots = []
	for i in range(1, MAX_SLOTS + 1):
		var path = SAVE_DIR + "save_" + str(i) + ".json"
		var data = {}
		if FileAccess.file_exists(path):
			var f = FileAccess.open(path, FileAccess.READ)
			data = JSON.parse_string(f.get_as_text()) or {}
		slots.append({
			"index": i,
			"exists": FileAccess.file_exists(path),
			"data": data,
			"timestamp": data.get("timestamp", ""),
			"score": data.get("score", 0),
			"health": data.get("health", 100),
		})
	return slots

func save_game(slot: int, player: Node3D, weapon_manager: Node):
	var data = {
		"timestamp": Time.get_datetime_string_from_system(),
		"health": player.health,
		"max_health": player.max_health,
		"score": player.score,
		"position": [player.position.x, player.position.y, player.position.z],
		"damage_mult": player.damage_multiplier,
		"fire_rate_mult": player.fire_rate_multiplier,
		"render_distance": player.render_distance,
		"weapons": weapon_manager.get_save_data(),
	}
	var path = SAVE_DIR + "save_" + str(slot) + ".json"
	var f = FileAccess.open(path, FileAccess.WRITE)
	f.store_string(JSON.new().stringify(data, "\t"))
	return true

func load_game(slot: int, player: Node3D, weapon_manager: Node, all_defs: Dictionary) -> bool:
	var path = SAVE_DIR + "save_" + str(slot) + ".json"
	if not FileAccess.file_exists(path):
		return false
	var f = FileAccess.open(path, FileAccess.READ)
	var data = JSON.parse_string(f.get_as_text())
	if data == null:
		return false

	player.health = data.get("health", 100)
	player.max_health = data.get("max_health", 100)
	player.score = data.get("score", 0)
	var pos = data.get("position", [0, 0.5, 0])
	player.position = Vector3(pos[0], pos[1], pos[2])
	player.damage_multiplier = data.get("damage_mult", 1.0)
	player.fire_rate_multiplier = data.get("fire_rate_mult", 1.0)
	player.render_distance = data.get("render_distance", 200.0)
	player.health_changed.emit(player.health)
	player.score_changed.emit(player.score)
	player.render_distance_changed.emit(player.render_distance)

	weapon_manager.load_from_data(data.get("weapons", {}), all_defs)
	return true
