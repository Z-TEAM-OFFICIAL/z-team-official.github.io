class_name ZShooterParser
static func parse_file(path: String) -> ZShooterScript:
    var f = FileAccess.open(path, FileAccess.READ)
    if f == null: return null
    var text = f.get_as_text()
    return parse_text(text, path)
    
static func parse_text(text: String, source: String = "") -> ZShooterScript:
    var script = ZShooterScript.new()
    script.source_path = source
    var lines = text.split("\n")
    var current_section = ""
    var current_override_id = ""
    var in_block = false
    var block_lines = []
    
    for line in lines:
        var trimmed = line.strip_edges()
        if trimmed.begins_with("#") or trimmed == "": continue
        
        if trimmed.begins_with("on_") and trimmed.contains("{"):
            # Section header like "on_init {"
            if in_block:
                push_error("Nested block in .zshooter file")
                continue
            current_section = trimmed.substr(0, trimmed.find("{")).strip_edges()
            in_block = true
            block_lines = []
            continue
            
        if trimmed.begins_with("override "):
            # "override weapon-id {"
            var rest = trimmed.substr("override ".length()).strip_edges()
            current_override_id = rest.substr(0, rest.find("{")).strip_edges()
            current_section = "override"
            in_block = true
            block_lines = []
            continue
            
        if trimmed == "}":
            if in_block:
                if current_section == "override":
                    _parse_override_block(script, current_override_id, block_lines)
                elif current_section.begins_with("on_"):
                    _parse_hook_block(script, current_section, block_lines)
                current_section = ""
                current_override_id = ""
                in_block = false
                block_lines = []
            continue
            
        if in_block:
            block_lines.append(trimmed)
            continue
            
        # Top-level key = value
        if "=" in trimmed:
            var eq_pos = trimmed.find("=")
            var key = trimmed.substr(0, eq_pos).strip_edges()
            var val = trimmed.substr(eq_pos + 1).strip_edges()
            # Strip quotes
            if val.begins_with("\"") and val.ends_with("\""):
                val = val.substr(1, val.length() - 2)
            match key:
                "name": script.name = val
                "version": script.version = val
                "description": script.description = val

    return script

static func _parse_hook_block(script: ZShooterScript, event: String, lines: Array):
    for line in lines:
        line = line.strip_edges()
        if line == "": continue
        # Command format: "func_name arg1 arg2 ..."
        var parts = _tokenize_line(line)
        if parts.size() > 0:
            var cmd = ZShooterScript.Command.new(parts[0], parts.slice(1))
            script.add_command(event, cmd)

static func _parse_override_block(script: ZShooterScript, weapon_id: String, lines: Array):
    for line in lines:
        line = line.strip_edges()
        if line == "": continue
        if "=" in line:
            var eq_pos = line.find("=")
            var key = line.substr(0, eq_pos).strip_edges()
            var val = line.substr(eq_pos + 1).strip_edges()
            # Try to parse as number first
            if val.is_valid_int():
                script.add_override(weapon_id, key, val.to_int())
            elif val.is_valid_float():
                script.add_override(weapon_id, key, val.to_float())
            else:
                script.add_override(weapon_id, key, val)

static func _tokenize_line(line: String) -> Array:
    var result = []
    var current = ""
    var in_quotes = false
    for i in range(line.length()):
        var c = line[i]
        if c == "\"":
            in_quotes = not in_quotes
            continue
        if c == " " and not in_quotes:
            if current != "":
                result.append(current)
                current = ""
            continue
        current += c
    if current != "":
        result.append(current)
    return result
