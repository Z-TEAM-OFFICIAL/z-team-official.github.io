extends Node

signal mod_loaded(script: ZShooterScript, dir_name: String)
signal mod_error(dir_name: String, message: String)

var loaded_mods: Dictionary = {}
var runtime: ZShooterRuntime = null
var mod_dirs: Array = []

func _ready():
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://mods"))

func init_runtime(player: Node3D, defs: Dictionary):
	runtime = ZShooterRuntime.new(player, defs)

func set_player(p: Node3D):
	if runtime:
		runtime.set_player(p)

func get_runtime() -> ZShooterRuntime:
	return runtime

func scan_mods() -> Array:
	loaded_mods.clear()
	mod_dirs.clear()
	var dir = DirAccess.open("res://mods")
	if dir == null:
		return []
	
	dir.list_dir_begin()
	var fname = dir.get_next()
	while fname != "":
		if dir.current_is_dir():
			mod_dirs.append(fname)
		fname = dir.get_next()
	dir.list_dir_end()
	return mod_dirs.duplicate()

func load_mod(dir_name: String) -> bool:
	var mod_dir = "res://mods/" + dir_name
	var dir = DirAccess.open(mod_dir)
	if dir == null:
		mod_error.emit(dir_name, "Directory not found")
		return false
	
	dir.list_dir_begin()
	var fname = dir.get_next()
	var zshooter_path = ""
	while fname != "":
		if fname.ends_with(".zshooter"):
			zshooter_path = mod_dir + "/" + fname
			break
		fname = dir.get_next()
	dir.list_dir_end()
	
	if zshooter_path == "":
		mod_error.emit(dir_name, "No .zshooter file found")
		return false
	
	var script = ZShooterParser.parse_file(zshooter_path)
	if script == null:
		mod_error.emit(dir_name, "Failed to parse .zshooter file")
		return false
	
	loaded_mods[dir_name] = script
	mod_loaded.emit(script, dir_name)
	return true

func load_all_mods():
	scan_mods()
	for d in mod_dirs:
		if is_mod_enabled(d):
			load_mod(d)

func unload_mod(dir_name: String):
	if dir_name in loaded_mods:
		loaded_mods.erase(dir_name)

func is_mod_enabled(dir_name: String) -> bool:
	var path = "user://mods/" + dir_name + ".enabled"
	return FileAccess.file_exists(path)

func set_mod_enabled(dir_name: String, enabled: bool):
	var path = "user://mods/" + dir_name + ".enabled"
	if enabled:
		var f = FileAccess.open(path, FileAccess.WRITE)
		if f:
			f.store_string("enabled")
	else:
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func get_mod_info(dir_name: String) -> Dictionary:
	var mod_dir = "res://mods/" + dir_name
	var info = {"name": dir_name, "version": "?", "description": "", "enabled": false, "loaded": false}
	info.enabled = is_mod_enabled(dir_name)
	info.loaded = dir_name in loaded_mods
	if dir_name in loaded_mods:
		var s: ZShooterScript = loaded_mods[dir_name]
		info.name = s.name
		info.version = s.version
		info.description = s.description
	return info

func fire_hook(event: String, context: Dictionary = {}):
	if runtime == null:
		return
	for dir_name in loaded_mods:
		var script = loaded_mods[dir_name]
		if script.has_hook(event):
			runtime.execute_hook(script, event, context)

func get_merged_overrides() -> Dictionary:
	var merged = {}
	if runtime == null:
		return merged
	for dir_name in loaded_mods:
		var script = loaded_mods[dir_name]
		var overrides = script.get_weapon_overrides()
		for wid in overrides:
			if not merged.has(wid):
				merged[wid] = {}
			for prop in overrides[wid]:
				merged[wid][prop] = overrides[wid][prop]
	return merged

func apply_all_overrides(base_defs: Dictionary) -> Dictionary:
	var defs = base_defs.duplicate(true)
	var overrides = get_merged_overrides()
	for wid in overrides:
		if wid in defs:
			var w = defs[wid]
			for prop in overrides[wid]:
				if w.has(prop):
					w[prop] = overrides[wid][prop]
	return defs
