extends Node3D

var player: Node3D
var hud: CanvasLayer
var menu_mgr: Control
var cheat_console: Control
var save_manager: Node
var network_manager: Node
var weapon_manager: Node
var mod_loader: Node
var spawn_timer: float = 0.0
var spawn_interval: float = 2.0
var game_over: bool = false

func _ready():
	player = $Player
	hud = $HUD
	menu_mgr = $MenuManager
	cheat_console = $CheatConsole
	save_manager = $SaveManager
	network_manager = $NetworkManager
	weapon_manager = player.weapon_manager
	mod_loader = $ModLoader

	player.add_to_group("player")

	player.health_changed.connect(hud.update_health)
	player.score_changed.connect(hud.update_score)
	player.player_died.connect(_on_player_died)
	player.render_distance_changed.connect(hud.update_render_distance)
	hud.update_health(player.health)
	hud.update_score(player.score)
	hud.update_render_distance(player.render_distance)

	menu_mgr.set_player(player)
	menu_mgr.set_hud(hud)
	menu_mgr.set_save_manager(save_manager)
	menu_mgr.set_cheat_console(cheat_console)

	weapon_manager.weapon_switched.connect(hud.update_weapon_display)
	weapon_manager.weapon_added.connect(_on_weapon_added)

	var defs = WeaponDB.all_defs()
	mod_loader.init_runtime(player, defs)
	mod_loader.load_all_mods()

	mod_loader.apply_all_overrides(defs)

	_give_starting_weapons()

	if Store.load_slot > 0:
		save_manager.load_game(Store.load_slot, player, weapon_manager, defs)
		Store.load_slot = -1

	var cfg = ConfigFile.new()
	cfg.load("user://settings.cfg")
	var vsync = cfg.get_value("settings", "v_sync", true)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if vsync else DisplayServer.VSYNC_DISABLED)

	if network_manager.is_host:
		hud.show_ip(network_manager.get_local_ip() + ":" + str(network_manager.get_port()))

	mod_loader.fire_hook("on_init")

func _give_starting_weapons():
	var runtime = mod_loader.get_runtime()
	if runtime:
		var wdefs = runtime.weapon_defs
		if "steel-pistol" in wdefs:
			weapon_manager.add_weapon(wdefs["steel-pistol"])
		if "steel-rifle" in wdefs:
			weapon_manager.add_weapon(wdefs["steel-rifle"])

func _process(delta):
	if game_over:
		return
	if get_tree().paused:
		return
	spawn_timer += delta
	if spawn_timer >= spawn_interval:
		spawn_timer = 0.0
		spawn_interval = max(0.5, spawn_interval - 0.05)
		spawn_enemy()

func spawn_enemy():
	var enemy_scene = preload("res://Src/Core/Enemy.tscn")
	var enemy = enemy_scene.instantiate()
	var offset = Vector3(randf_range(-10, 10), 0, randf_range(-10, 10))
	if offset.length() < 5:
		offset = offset.normalized() * 5
	enemy.position = player.position + offset
	enemy.position.y = 0.5
	enemy.died.connect(_on_enemy_died)
	enemy.add_to_group("enemies")
	add_child(enemy)

func _on_enemy_died(score_value: int):
	player.add_score(score_value)
	mod_loader.fire_hook("on_kill", {"score": score_value})

func _on_player_died():
	game_over = true
	hud.show_game_over()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	mod_loader.fire_hook("on_death")

func _on_weapon_added(_weapon):
	hud.update_weapon_display(weapon_manager.current_index, weapon_manager.get_current_weapon())
