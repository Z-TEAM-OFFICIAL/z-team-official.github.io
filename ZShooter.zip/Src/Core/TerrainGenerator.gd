extends StaticBody3D

const SIZE = 60
const SEGMENTS = 80
const FLAT_RADIUS = 6
const HILL_HEIGHT = 3.0
const NOISE_SCALE = 0.05

func _ready():
	generate()

func generate():
	var noise = FastNoiseLite.new()
	noise.seed = randi()
	noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	noise.fractal_octaves = 4
	noise.fractal_lacunarity = 2.0
	noise.fractal_gain = 0.5
	noise.frequency = NOISE_SCALE

	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	var half = SIZE * 0.5
	var step = SIZE / float(SEGMENTS)

	var heights: PackedFloat32Array
	heights.resize((SEGMENTS + 1) * (SEGMENTS + 1))

	for iz in range(SEGMENTS + 1):
		for ix in range(SEGMENTS + 1):
			var x = -half + ix * step
			var z = -half + iz * step
			var dist = Vector2(x, z).length()
			var flat = clamp((dist - FLAT_RADIUS) / 2.0, 0.0, 1.0)
			var h = noise.get_noise_2d(x, z) * HILL_HEIGHT * flat

			var idx = iz * (SEGMENTS + 1) + ix
			heights[idx] = h

			var u = Vector2(ix, iz) / SEGMENTS
			st.set_uv(u)
			st.add_vertex(Vector3(x, h, z))

	for iz in range(SEGMENTS):
		for ix in range(SEGMENTS):
			var i0 = iz * (SEGMENTS + 1) + ix
			var i1 = iz * (SEGMENTS + 1) + ix + 1
			var i2 = (iz + 1) * (SEGMENTS + 1) + ix
			var i3 = (iz + 1) * (SEGMENTS + 1) + ix + 1

			st.add_index(i0)
			st.add_index(i1)
			st.add_index(i2)
			st.add_index(i1)
			st.add_index(i3)
			st.add_index(i2)

	st.generate_normals()

	var mesh = st.commit()
	$MeshInstance3D.mesh = mesh

	var height_shape = HeightMapShape3D.new()
	height_shape.map_width = SEGMENTS + 1
	height_shape.map_depth = SEGMENTS + 1
	height_shape.map_data = heights
	$CollisionShape3D.shape = height_shape
