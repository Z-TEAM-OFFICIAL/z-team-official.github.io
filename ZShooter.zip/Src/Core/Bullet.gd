extends Area3D

const SPEED = 30.0
const LIFETIME = 2.0

var damage: int = 25
var time: float = 0.0

func _ready():
	body_entered.connect(_on_hit)

func _process(delta):
	time += delta
	if time > LIFETIME:
		queue_free()
	position += -transform.basis.z * SPEED * delta

func _on_hit(body: Node):
	if body.is_in_group("player"):
		return
	if body.has_method("take_damage"):
		body.take_damage(damage)
	queue_free()
