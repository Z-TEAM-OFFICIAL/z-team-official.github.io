extends Node

var load_slot: int = -1
