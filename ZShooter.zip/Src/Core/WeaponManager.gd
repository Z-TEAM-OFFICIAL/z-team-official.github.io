extends Node

signal weapon_switched(index: int, weapon: WeaponDef)
signal weapon_added(weapon: WeaponDef)

var weapons: Array[WeaponDef] = []
var current_index: int = -1
var ammo: Dictionary = {}

func get_current_weapon() -> WeaponDef:
	if current_index < 0 or current_index >= weapons.size():
		return null
	return weapons[current_index]

func get_current_ammo() -> int:
	var w = get_current_weapon()
	if w == null:
		return 0
	return ammo.get(w.id, get_max_ammo(w))

func get_max_ammo(w: WeaponDef) -> int:
	match w.weapon_type:
		"lightweight-machinegun": return 250
		"pistol": return 120
		"rifle": return 90
		"shotgun": return 40
		"heavy-rifle": return 60
		"sniper": return 25
		"rpg": return 10
	return 100

func add_weapon(w: WeaponDef):
	if has_weapon(w.id):
		return
	weapons.append(w)
	ammo[w.id] = get_max_ammo(w)
	weapon_added.emit(w)
	if current_index < 0:
		current_index = 0
		weapon_switched.emit(current_index, w)

func has_weapon(id: String) -> bool:
	for w in weapons:
		if w.id == id:
			return true
	return false

func switch_to(index: int):
	if index < 0 or index >= weapons.size() or index == current_index:
		return
	current_index = index
	weapon_switched.emit(current_index, weapons[current_index])

func switch_next():
	switch_to((current_index + 1) % weapons.size())

func switch_prev():
	switch_to((current_index - 1 + weapons.size()) % weapons.size())

func consume_ammo() -> bool:
	var w = get_current_weapon()
	if w == null:
		return false
	if ammo.get(w.id, 0) <= 0:
		return false
	ammo[w.id] = ammo.get(w.id, 0) - 1
	return true

func add_ammo(id: String, amount: int):
	ammo[id] = min(ammo.get(id, 0) + amount, get_max_ammo(_get_def(id)))

func _get_def(id: String) -> WeaponDef:
	for w in weapons:
		if w.id == id:
			return w
	return null

func get_save_data() -> Dictionary:
	var data = {
		"weapons": [],
		"ammo": {},
		"current_index": current_index,
	}
	for w in weapons:
		data["weapons"].append(w.id)
		data["ammo"][w.id] = ammo.get(w.id, 0)
	return data

func load_from_data(data: Dictionary, defs: Dictionary):
	weapons.clear()
	ammo.clear()
	for wid in data.get("weapons", []):
		if wid in defs:
			weapons.append(defs[wid])
			ammo[wid] = data.get("ammo", {}).get(wid, get_max_ammo(defs[wid]))
	current_index = data.get("current_index", -1)
	if current_index >= 0 and current_index < weapons.size():
		weapon_switched.emit(current_index, weapons[current_index])
