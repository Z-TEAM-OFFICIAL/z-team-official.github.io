class_name ZShooterRuntime

var player: Node3D = null
var weapon_defs: Dictionary = {}

func _init(p: Node3D, defs: Dictionary):
	player = p
	weapon_defs = defs.duplicate(true)

func get_player() -> Node3D:
	return player

func set_player(p: Node3D):
	player = p

func execute_hook(script: ZShooterScript, event: String, context: Dictionary = {}):
	if not script.has_hook(event):
		return
	for cmd in script.get_hook(event):
		_execute_command(cmd, context)

func apply_overrides(script: ZShooterScript) -> Dictionary:
	var modified = weapon_defs.duplicate(true)
	for wid in script.get_weapon_overrides():
		if wid in modified:
			var w = modified[wid]
			var props = script.get_weapon_overrides()[wid]
			for key in props:
				if key in w:
					w[key] = props[key]
	return modified

func _execute_command(cmd: ZShooterScript.Command, _context: Dictionary):
	match cmd.func_name:
		"log":
			if cmd.args.size() > 0:
				print("[ZShooter] " + cmd.args[0])
		"give_weapon":
			if player and cmd.args.size() > 0:
				var wm = player.get("weapon_manager")
				if wm and cmd.args[0] in weapon_defs:
					wm.add_weapon(weapon_defs[cmd.args[0]])
		"add_score":
			if player and cmd.args.size() > 0:
				player.add_score(int(cmd.args[0]))
		"set_player_health":
			if player and cmd.args.size() > 0:
				player.health = clampi(int(cmd.args[0]), 0, player.max_health)
				player.health_changed.emit(player.health)
		"god_mode":
			if player and cmd.args.size() > 0:
				player.god_mode = (cmd.args[0].to_lower() == "true" or cmd.args[0] == "1")
		"spawn_enemy":
			var main = player.get_parent()
			if main and main.has_method("spawn_enemy"):
				main.spawn_enemy()
		"set_game_property":
			if cmd.args.size() >= 2:
				var key = cmd.args[0]
				var val = cmd.args[1]
				if key == "damage_mult" and player:
					player.damage_multiplier = float(val)
				elif key == "fire_rate_mult" and player:
					player.fire_rate_multiplier = float(val)
