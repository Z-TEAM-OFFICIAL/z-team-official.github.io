extends Node3D

const SPEED = 3.0
const DAMAGE = 10

var health: int = 50
var score_value: int = 100
var player: Node3D = null
var time: float = 0.0

signal died(score)

func _ready():
	player = get_tree().get_first_node_in_group("player")

func _process(delta):
	if not player:
		player = get_tree().get_first_node_in_group("player")
		return

	time += delta
	var to_player = player.global_position - global_position
	to_player.y = 0
	if to_player.length() < 0.1:
		return
	var dir = to_player.normalized()
	global_position += dir * SPEED * delta
	if dir.length_squared() > 0:
		look_at(global_position + dir, Vector3.UP)
	global_position.y = sin(time * 4) * 0.3

	for body in $Area3D.get_overlapping_bodies():
		if body == player:
			player.take_damage(DAMAGE)

func take_damage(amount: int):
	health -= amount
	if $Model.material_override:
		var tween = create_tween()
		tween.tween_property($Model, "material_override:albedo_color", Color.WHITE, 0.05)
		tween.tween_property($Model, "material_override:albedo_color", Color(1, 0.2, 0.1), 0.1)
	if health <= 0:
		died.emit(score_value)
		queue_free()
