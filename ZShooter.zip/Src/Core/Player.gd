extends CharacterBody3D

@export var walk_speed = 5.0
@export var sprint_speed = 8.0
@export var crouch_speed = 2.5
@export var jump_velocity = 6.0
@export var mouse_sensitivity = 0.002

var speed
var health = 100
var max_health = 100
var score = 0
var gravity = 0.0
var is_crouching = false
var was_on_floor = true
var god_mode = false

var damage_multiplier = 1.0
var fire_rate_multiplier = 1.0
var render_distance = 200.0

signal health_changed(new_health)
signal score_changed(new_score)
signal player_died
signal render_distance_changed(dist)

@onready var camera = $Camera3D
@onready var camera_pos = camera.position
@onready var muzzle = $Camera3D/Muzzle
@onready var weapon_model = $Camera3D/WeaponModel
@onready var collision = $CollisionShape3D
@onready var standing_height = collision.shape.height
@onready var audio_footsteps = $Footsteps
@onready var shoot_cooldown = $ShootCooldown
@onready var weapon_manager = $WeaponManager

func _ready():
	speed = walk_speed
	load_settings()

func load_settings():
	var cfg = ConfigFile.new()
	cfg.load("user://settings.cfg")
	mouse_sensitivity = cfg.get_value("settings", "mouse_sensitivity", 0.3) * 0.006
	if cfg.get_value("settings", "mouse_lock", true):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	else:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func apply_settings():
	load_settings()

func _input(event):
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x - event.relative.y * mouse_sensitivity, -1.5, 1.5)
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			shoot()
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			render_distance = clamp(render_distance + 20, 50, 500)
			camera.far = render_distance
			render_distance_changed.emit(render_distance)
		if event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			render_distance = clamp(render_distance - 20, 50, 500)
			camera.far = render_distance
			render_distance_changed.emit(render_distance)
	if event is InputEventKey:
		if event.pressed and not event.echo:
			match event.keycode:
				KEY_1: weapon_manager.switch_to(0)
				KEY_2: weapon_manager.switch_to(1)
				KEY_3: weapon_manager.switch_to(2)
				KEY_4: weapon_manager.switch_to(3)
				KEY_5: weapon_manager.switch_to(4)
				KEY_6: weapon_manager.switch_to(5)
				KEY_7: weapon_manager.switch_to(6)

func _process(delta):
	handle_weapon_bob(delta)

func _physics_process(delta):
	handle_gravity(delta)
	handle_movement(delta)
	handle_crouch(delta)
	handle_sprint()
	move_and_slide()
	handle_landing()
	handle_footsteps()

func handle_gravity(delta):
	gravity += 25.0 * delta
	if gravity > 0 and is_on_floor():
		gravity = 0.0
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		gravity = -jump_velocity
	if gravity < 0 and is_on_ceiling():
		gravity = 0.0
	velocity.y = -gravity

func handle_movement(delta):
	var input = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var dir = (transform.basis * Vector3(input.x, 0, input.y)).normalized()
	var target_speed = speed
	if not is_on_floor():
		target_speed *= 0.5
	var target_vel = dir * target_speed
	velocity.x = move_toward(velocity.x, target_vel.x, 15.0 * delta)
	velocity.z = move_toward(velocity.z, target_vel.z, 15.0 * delta)

func handle_sprint():
	if Input.is_key_pressed(KEY_SHIFT) and is_on_floor() and not is_crouching:
		speed = sprint_speed
	else:
		speed = walk_speed

func handle_crouch(delta):
	if Input.is_key_pressed(KEY_CTRL):
		is_crouching = true
		speed = crouch_speed
		camera.position.y = move_toward(camera.position.y, -0.5, 5.0 * delta)
		collision.shape.height = move_toward(collision.shape.height, 0.8, 5.0 * delta)
	else:
		var space = move_toward(collision.shape.height, standing_height, 5.0 * delta)
		if not test_move(transform, Vector3.UP * (space - collision.shape.height)):
			collision.shape.height = space
			is_crouching = false
			camera.position.y = move_toward(camera.position.y, camera_pos.y, 5.0 * delta)

func handle_landing():
	if is_on_floor() and not was_on_floor and gravity > 2.0:
		camera.position.y = -0.08
	was_on_floor = is_on_floor()

func handle_footsteps():
	if not audio_footsteps:
		return
	audio_footsteps.stream_paused = true
	if is_on_floor() and abs(velocity.x) > 0.5 or abs(velocity.z) > 0.5:
		audio_footsteps.stream_paused = false

func handle_weapon_bob(delta):
	var bob_speed = 8.0
	var bob_amount = 0.005
	if is_on_floor() and velocity.length() > 0.5:
		var bob = sin(Time.get_ticks_msec() * 0.001 * bob_speed) * bob_amount
		weapon_model.position.y = bob
		weapon_model.rotation.z = sin(Time.get_ticks_msec() * 0.001 * bob_speed * 0.5) * bob_amount * 0.5
	else:
		weapon_model.position.y = move_toward(weapon_model.position.y, 0.0, delta * 5.0)
		weapon_model.rotation.z = move_toward(weapon_model.rotation.z, 0.0, delta * 5.0)

func shoot():
	var w = weapon_manager.get_current_weapon()
	if w == null:
		return
	if not shoot_cooldown.is_stopped():
		return
	if not weapon_manager.consume_ammo():
		return

	shoot_cooldown.start(w.fire_rate * fire_rate_multiplier)

	var bullet = preload("res://Src/Core/Bullet.tscn").instantiate()
	get_tree().root.add_child(bullet)
	bullet.global_transform = muzzle.global_transform
	bullet.damage = int(w.damage * damage_multiplier)

	var tween = create_tween()
	tween.tween_property(weapon_model, "position", Vector3(randf_range(-0.005, 0.005), -0.02, -0.03), 0.02)
	tween.tween_property(weapon_model, "position", Vector3.ZERO, 0.1)
	tween.parallel().tween_property(weapon_model, "rotation_degrees", Vector3(randf_range(-1, 1), 0, randf_range(-0.5, 0.5)), 0.02)
	tween.parallel().tween_property(weapon_model, "rotation_degrees", Vector3.ZERO, 0.1)

func take_damage(amount):
	if god_mode:
		return
	health -= amount
	health_changed.emit(health)
	if health <= 0:
		health = 0
		player_died.emit()
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func add_score(amount):
	score += amount
	score_changed.emit(score)
