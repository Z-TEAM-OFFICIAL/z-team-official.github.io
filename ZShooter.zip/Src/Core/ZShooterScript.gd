class_name ZShooterScript
extends Resource

var name: String = "Unnamed Mod"
var version: String = "1.0"
var description: String = ""
var source_path: String = ""
var hooks: Dictionary = {}  # event_name -> Array of Command
var overrides: Dictionary = {}  # weapon_id -> {property: value}

class Command:
    var func_name: String
    var args: Array
    func _init(f: String, a: Array):
        func_name = f
        args = a

func has_hook(event: String) -> bool: return hooks.has(event)
func get_hook(event: String) -> Array: return hooks.get(event, [])
func add_command(event: String, cmd: Command):
    if not hooks.has(event): hooks[event] = []
    hooks[event].append(cmd)
func add_override(weapon_id: String, property: String, value):
    if not overrides.has(weapon_id): overrides[weapon_id] = {}
    overrides[weapon_id][property] = value
