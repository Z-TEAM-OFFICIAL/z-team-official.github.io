extends Node

var peer = null
var is_host = false

func get_local_ip():
	var ips = IP.get_local_addresses()
	for addr in ips:
		if addr.begins_with("192.168.") or addr.begins_with("10."):
			return addr
	return "127.0.0.1"

func get_port():
	return 7777

func host_game():
	peer = ENetMultiplayerPeer.new()
	var err = peer.create_server(get_port(), 4)
	if err != OK:
		return false
	multiplayer.multiplayer_peer = peer
	is_host = true
	return true

func join_game(ip, port):
	peer = ENetMultiplayerPeer.new()
	var err = peer.create_client(ip, port)
	if err != OK:
		return false
	multiplayer.multiplayer_peer = peer
	is_host = false
	return true

func net_disconnect():
	multiplayer.multiplayer_peer = null
	peer = null
	is_host = false

func is_network_connected():
	return multiplayer.multiplayer_peer != null
