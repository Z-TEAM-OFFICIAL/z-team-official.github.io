"""
ZShooter Texture Baker
Bakes textures onto GLB models, keeping backups.

Usage:
    python bake_textures.py <model.glb> <texture.png> [--output model_textured.glb]

Requires: pip install pygltflib Pillow numpy
"""

import os
import sys
import shutil
import argparse
from pathlib import Path

try:
    import pygltflib
    from PIL import Image
    import numpy as np
except ImportError as e:
    print(f"Missing dependency: {e}")
    print("Install with: pip install pygltflib Pillow numpy")
    sys.exit(1)

BACKUP_DIR = "_backups"


def backup_file(path: str) -> str:
    src = Path(path)
    dst = Path(BACKUP_DIR) / f"{src.stem}_{src.suffix.replace('.','')}_backup{src.suffix}"
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f"Backup saved: {dst}")
    return str(dst)


def bake_texture(glb_path: str, tex_path: str, output_path: str = None):
    if not os.path.exists(glb_path):
        print(f"Error: model not found: {glb_path}")
        sys.exit(1)
    if not os.path.exists(tex_path):
        print(f"Error: texture not found: {tex_path}")
        sys.exit(1)

    backup_file(glb_path)

    glb = pygltflib.GLTF2().load(glb_path)

    img = Image.open(tex_path).convert("RGBA")
    img_data = np.array(img, dtype=np.uint8).tobytes()

    image_index = len(glb.images)
    glb.images.append(pygltflib.Image(
        name=os.path.basename(tex_path),
        uri=tex_path,
        mimeType="image/png"
    ))

    texture_index = len(glb.textures)
    glb.textures.append(pygltflib.Texture(
        source=image_index,
        sampler=0
    ))

    tex_info = pygltflib.TextureInfo(index=texture_index, texCoord=0)
    pbr = pygltflib.MaterialPBRMetallicRoughness(
        baseColorTexture=tex_info,
        metallicFactor=0.8,
        roughnessFactor=0.3,
    )

    if glb.materials:
        glb.materials[0].pbrMetallicRoughness = pbr
        print(f"Updated existing material on {glb_path}")
    else:
        glb.materials.append(pygltflib.Material(
            name="textured",
            pbrMetallicRoughness=pbr,
        ))
        print(f"Created new material on {glb_path}")

    if output_path is None:
        stem = Path(glb_path).stem
        output_path = str(Path(glb_path).parent / f"{stem}_textured.glb")

    glb.save(output_path)
    print(f"Saved textured model: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bake texture onto GLB model")
    parser.add_argument("model", help="Path to input .glb model")
    parser.add_argument("texture", help="Path to texture image (PNG)")
    parser.add_argument("--output", "-o", help="Output .glb path (optional)")
    args = parser.parse_args()
    bake_texture(args.model, args.texture, args.output)
